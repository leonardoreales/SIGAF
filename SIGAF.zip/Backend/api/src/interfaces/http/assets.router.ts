import { Router } from 'express'
import * as controller from './assets.controller'

const router = Router()

router.get('/',      controller.list)
router.get('/:id',   controller.getOne)
router.post('/',     controller.create)
router.put('/:id',   controller.update)
router.delete('/:id', controller.remove)

export default router
